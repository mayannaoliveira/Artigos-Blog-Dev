Import-Module PSReadLine
Set-PSReadLineOption -PredictionSource History
Set-PSReadLineOption -PredictionViewStyle ListView
Set-PSReadLineOption -EditMode Windows

import-Module oh-my-posh
Set-PoshPrompt -Theme JanDeDobbeleer
oh-my-posh config migrate glyphs --write
oh-my-posh --init --shell pwsh --config C:\Users\Dev\Documents\PowerShell\mytheme.omp.json | Invoke-Expression